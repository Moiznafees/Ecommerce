import React from 'react'
import { useState } from 'react'
import Layout from '../components/Layout'
import Loader from './Loader'

const Home = () => {
  const [loading , setLoading ] = useState(true)
  return (
   <Layout>
    {
      loading ? (<Loader/>) : (<h1>welcome to home page </h1>)
    }
   
   </Layout>
  )
}

export default Home
