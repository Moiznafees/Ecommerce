import { createSlice } from "@reduxjs/toolkit";

const cartSlice = createSlice({
    products:[],
    product:null,
    error:null,
    loading:false,
    favoritesToggled:[],
    initialState: {
        name:"products",
    },
    reducers: {
    setLoading:(state)=>{
       state.loading=true;
    },
    setProducts:(state,action)=>{
        state.loading = false;
        state.error = null;
        state.products=action.payload;

    },
    setError:(state)=>{
        state.loading = false;
     state.error = null
    },

    setFavoritesToggled:(state,action)=>{
        state.favoritesToggled=action.payload;
    }}
})

export const {setLoading , setError , setProducts ,setFavoritesToggled } = cartSlice.actions;

export default cartSlice.reducer;

