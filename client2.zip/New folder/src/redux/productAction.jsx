import axios from "axios"
import { setError, setLoading, setProducts } from "./cartSlice"


export const  fetchProduct = ()=>{
    async (dispatch)=>{
        dispatch(setLoading())
    try{
        const {data} = await axios.get('http://localhost:8080/products')
       const {products , pagination } = data;
        dispatch(setProducts(products))
        }catch(error){
            dispatch(setError(
                error.response && error.response.data.message 
                                  ? error.response.data.message
                                  : error.message 
                                  ? error.message 
                                  : "An expected error has occured. Please try again later"  
            ))
         
            }
            }
}

